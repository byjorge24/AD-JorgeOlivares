/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

import java.util.Comparator;

/**
 *
 * @author jorge
 */
public abstract class Figura implements Dibujable {
    
    public static Punto origen = new Punto();
    
    public abstract double area();
    
    public abstract double perimetro();
    
    public static double distancia(Figura f){
        
        double distancia1 = Math.pow(f.origen.getX(), origen.getX());
        
        double distancia2 = Math.pow(f.origen.getY(), origen.getY());
        
        double distancia = Math.sqrt(distancia1 + distancia2);
        
        return distancia;
        
    }
    
    public abstract void escalar(int porcentaje);
    
    public void mover(Punto origen2){
        
        this.setOrigen(origen2);
        
    }
    
    public static void desplazarh(double x){
        
        if (x > 0){
            
            origen.setX(origen.getX() + x);
            
        }
        else {
            
            origen.setX(origen.getX() - x);
            
        }
        
    }
    
    public static void desplazarv(double y){
        
        if (y > 0){
            
            origen.setY(origen.getY() + y);
            
        }
        else {
            
            origen.setY(origen.getY() + y);
            
        }
        
    }
    
    private static int id;
    
    private static String borde;
    
    private static String relleno;

    /**
     * @return the origen
     */
    public Punto getOrigen() {
        return origen;
    }

    /**
     * @param origen the origen to set
     */
    public void setOrigen(Punto origen) {
        this.origen = origen;
    }

    /**
     * @return the id
     */
    public static int getId() {
        return id;
    }

    /**
     * @param aId the id to set
     */
    public static void setId(int aId) {
        id = aId;
    }

    /**
     * @return the borde
     */
    public static String getBorde() {
        return borde;
    }

    /**
     * @param aBorde the borde to set
     */
    public static void setBorde(String aBorde) {
        borde = aBorde;
    }

    /**
     * @return the relleno
     */
    public static String getRelleno() {
        return relleno;
    }

    /**
     * @param aRelleno the relleno to set
     */
    public static void setRelleno(String aRelleno) {
        relleno = aRelleno;
    }

    @Override
    public void dibujar(){
        
        
        
    }
    
    @Override
    public void rellenar(){
        
        
        
    }
    
    /* Comentado aqui abajo dejo los comparadores, no sabia muy bien como hacerlos funcionar
    El primer comparador, ordena las figuras por el area.
    El segundo comparador, las ordena por el perimetro.
    Y el tercer comparador, las ordena por la posición.
    */
    
    /*
    class ComparadorFiguraArea implements Comparator<Figura> {
        
        @Override
        public int compare(Figura f1, Figura f2){
            
            return f1.area() - f2.area();
            
        }
        
    }
    */
    
    /*
    class ComparadorFiguraPerimetro implements Comparator<Figura> {
        
        @Override
        public int compare(Figura f1, Figura f2){
            
            return f1.perimetro() - f2.perimetro();
            
        }
        
    }
    */
    
    /*
    class ComparadorFiguraPosicion implements Comparator <Figura> {
        
        @Override
        public int compare(Figura f1, Figura f2){
            
            return f1.getOrigen() - f2.getOrigen();
            
        }
        
    }
    */
}
