/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author jorge
 */
public class Practica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // TODO code application logic here
        
        Scanner reader = new Scanner (System.in);
        
        String continuar = "s";
        
        while ("s".equals(continuar)){
            
            System.out.println("----------------------------------------------------");

            System.out.println("-------------------- PRACTICA 1 --------------------");

            System.out.println("----------------------------------------------------");

            System.out.println("");

            System.out.println("1. Menú");
            
            System.out.println("2. Submenú crear figuras");

            System.out.println("3. Salir");

            int respuesta;

            System.out.println("----------------------------------------------------");

            System.out.println("");

            System.out.print("Elige una opción: ");

            respuesta = reader.nextInt();

            if (respuesta == 1){

                System.out.println("----------------------------------------------------");

                System.out.println("----------------------- MENÚ -----------------------");

                System.out.println("----------------------------------------------------");


                System.out.println("");

                System.out.println("1. Listar");

                System.out.println("2. Dibujar");

                System.out.println("3. Perímetros");

                System.out.println("4. Areas");

                System.out.println("5. Escalar");

                System.out.println("6. Mover");

                System.out.println("7. Desplazar");

                System.out.println("8. Ordenar");

                System.out.println("9. Salir");

                System.out.println("----------------------------------------------------");

                System.out.println("");

                int respuesta1;

                System.out.print("Elige una opción: ");

                respuesta1 = reader.nextInt();

                if (respuesta1 == 1){

                    Lienzo.llistar();

                }
                if (respuesta1 == 2){

                    Lienzo.dibujar();

                }
                if (respuesta1 == 3){

                    Lienzo.perimetro();

                }
                if (respuesta1 == 4){

                    Lienzo.area();

                }
                
                if (respuesta1 == 5){
                    
                    System.out.println("----------------------------------------------------");

                    System.out.println("------------------ SUBMENÚ ESCALAR -------------------");

                    System.out.println("----------------------------------------------------");

                    System.out.println("1. Escalar");

                    System.out.println("2. Salir");

                    System.out.println("");

                    System.out.print("Elegir una opción: ");

                    int respuesta3 = reader.nextInt();

                    if (respuesta3 == 1){

                        System.out.print("Introduce el ID de la figura: ");

                        int id = reader.nextInt();


                        System.out.print("Introduce el porcentaje que quieres escalar: ");

                        int porcentaje = reader.nextInt();
                        
                        System.out.println("");
                        
                        Lienzo.escalar(id, porcentaje);
                        
                        System.out.println("La figura se ha escalado correctamente!!!");
                        
                    }
                    if (respuesta3 == 2){



                    }
                }
                
                if (respuesta1 == 6){

                    System.out.println("----------------------------------------------------");

                    System.out.println("------------------ SUBMENÚ MOVER -------------------");

                    System.out.println("----------------------------------------------------");

                    System.out.println("1. Mover");

                    System.out.println("2. Salir");

                    System.out.println("");

                    System.out.print("Elegir una opción: ");

                    int respuesta4 = reader.nextInt();
                        
                    if (respuesta4 == 1){
                        
                        Punto origen = null;
                        
                        System.out.print("Introduce el ID de la figura: ");

                        int id = reader.nextInt();
                        
                        System.out.println("");
                        
                        System.out.print("Introduce el valor de X: ");
                        
                        double x = reader.nextInt();
                        
                        System.out.println("");
                        
                        System.out.print("Introduce el valor de Y: ");
                        
                        double y = reader.nextInt();
                        
                        System.out.println("");
                        
                        Lienzo.mover(id, origen);

                    }
                    if (respuesta4 == 2){

                        

                    }
                }

                if (respuesta1 == 7){
                    
                    System.out.println("----------------------------------------------------");

                    System.out.println("------------------ SUBMENÚ DESPLAZAR -------------------");

                    System.out.println("----------------------------------------------------");

                    System.out.println("1. Desplazar horizontalmente");

                    System.out.println("2. Desplazar verticalmente");

                    System.out.println("3. Salir");

                    System.out.println("");

                    System.out.print("Elige una opción: ");

                    int respuesta5 = reader.nextInt();

                    if (respuesta5 == 1){
                        
                        System.out.print("Introduce el ID: ");
                        
                        int id = reader.nextInt();
                        
                        System.out.print("Introduce la cifra a desplazar horizontalmente: ");

                        double x = reader.nextDouble();

                        Lienzo.desplazarh(id, x);

                    }
                    if (respuesta5 == 2){

                        System.out.print("Introduce el ID: ");
                        
                        int id = reader.nextInt();
                        
                        System.out.print("Introduce la cifra a desplazar verticalmente: ");

                        double y = reader.nextDouble();

                        Lienzo.desplazarv(id, y);

                    }
                    if (respuesta5 == 3){



                    }
                }
                
                if (respuesta1 == 8){

                    ArrayList<Figura> contenedorOrdenado = new ArrayList();

                    System.out.println("----------------------------------------------------");

                    System.out.println("------------------ SUBMENÚ ORDEN -------------------");

                    System.out.println("----------------------------------------------------");

                    System.out.println("1. Ordenar por area");

                    System.out.println("2. Ordenar por perimetro");

                    System.out.println("3. Ordenar por posición");

                    System.out.println("4. Mostrar ordenado");

                    System.out.println("5. Mostrar sin ordenar");

                    System.out.println("6. Salir");

                    System.out.println("----------------------------------------------------");

                    int respuesta2;

                    System.out.print("Elige una opción: ");

                    respuesta2 = reader.nextInt();

                    if (respuesta2 == 1){

                        /* Aqui ordenariamos las figuras por su area */

                    }
                    if (respuesta2 == 2){

                        /* Aqui ordenariamos las figuras por su perimetro */

                    }
                    if (respuesta2 == 3){

                        /* Aqui ordenariamos las figuras por su posición */

                    }
                    if (respuesta2 == 4){

                        System.out.println("--------------- ArrayList Ordenado ---------------");

                        for (int i = 0;  i < contenedorOrdenado.size(); i++){

                            System.out.println(contenedorOrdenado.get(i));

                        }

                    }
                    if (respuesta2 == 5){

                        System.out.println("--------------- ArrayList sin Ordenar ---------------");

                        for (int i = 0; i < Lienzo.contenedor.size(); i++){

                            System.out.println(Lienzo.contenedor.get(i));

                        }

                    }
                    if (respuesta2 == 6){



                    }
                }

                if (respuesta1 == 9){



                }


            }
            if (respuesta == 2){
                
                System.out.println("------------------ SUBMENÚ CREAR -------------------");
                
                System.out.println("1. Crear 10 Figuras Aleatorias");
                
                System.out.println("2. Mostrar Figuras");
                
                System.out.println("3. Mostrar ID Figuras");
                
                System.out.println("4. Asignar ID a las figuras");
                
                System.out.println("5. Salir");
                
                System.out.println("");
                
                System.out.print("Elige una opción: ");
                
                int respuesta6 = reader.nextInt();
                
                if (respuesta6 == 1){
                    
                    for (int i = 0; i <= 10; i++){
                        
                        int nAleatorio1 = (int) (Math.random()*4+1);
                        
                        if (nAleatorio1 == 1){

                            double ladoAleatorio1 = (double) (Math.random()*1000+1);

                            Cuadrado cuadrado1 = new Cuadrado(ladoAleatorio1);
                            
                            Lienzo.contenedor.add(cuadrado1);
                            
                        }
                        if (nAleatorio1 == 2){

                            double baseAleatoria1 = (double) (Math.random()*1000+1);
                            double alturaAleatoria1 = (double) (Math.random()*1000+1);

                            Rectangulo rectangulo1 = new Rectangulo(baseAleatoria1, alturaAleatoria1);
                            
                            Lienzo.contenedor.add(rectangulo1);
                            
                        }
                        if (nAleatorio1 == 3){

                            double radioAleatorio1 = (double) (Math.random()*1000+1);

                            Circulo circulo1 = new Circulo(radioAleatorio1);
                            
                            Lienzo.contenedor.add(circulo1);
                            
                        }
                        if (nAleatorio1 == 4){

                            double baseAleatoria1 = (double) (Math.random()*1000+1);
                            double alturaAleatoria1 = (double) (Math.random()*1000+1);

                            Triangulo triangulo1 = new Triangulo(baseAleatoria1, alturaAleatoria1);
                            
                            Lienzo.contenedor.add(triangulo1);
                            
                        }
                    }
                }
                if (respuesta6 == 2){
                    
                    Lienzo.llistar();
                    
                }
                if (respuesta6 == 3){
                    
                    for (int i = 0; i < Lienzo.contenedor.size(); i++){
                        
                        System.out.println(Lienzo.contenedor.get(i).getId());
                        
                    }
                    
                }
                if (respuesta6 == 4){
                    
                    for (int i = 0; i < 10; i++){
                        
                        System.out.println(i);
                        
                        Lienzo.contenedor.get(i).setId(i);
                        
                    }
                    
                }
                
                if (respuesta6 == 5){
                    
                    
                    
                }
            }
            
            if (respuesta == 3){

                System.exit(0);

            }


        }
    }
}
