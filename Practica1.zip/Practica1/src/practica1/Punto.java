/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;

/**
 *
 * @author jorge
 */
public class Punto {
    
    private static double x;
    private static double y;
    
    public void Punto(double x2, double y2){
        
        this.x = x2;
        this.y = y2;
        
    }
    
    /**
     * @return the x
     */
    public static double getX() {
        return x;
    }

    /**
     * @param aX the x to set
     */
    public static void setX(double aX) {
        x = aX;
    }

    /**
     * @return the y
     */
    public static double getY() {
        return y;
    }

    /**
     * @param aY the y to set
     */
    public static void setY(double aY) {
        y = aY;
    }

    @Override
    public String toString() {
        return ("x: " + this.x + "y: " + this.y);
    }

    
    
}
