/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaficheros;

import java.io.File;
import java.io.FileFilter;
import java.util.Scanner;

/**
 *
 * @author jorge
 */
public class SistemaFicheros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner reader = new Scanner (System.in);
        
        System.out.println("--------------- MENÚ ---------------");
        System.out.println("1. Ver por lista");
        System.out.println("2. Ver por columnas");
        System.out.println("3. Ver por tablas");
        
        
        System.out.print("Elige una opción: ");
        int respuesta = reader.nextInt();
        
        if (respuesta == 1){
            
            verLista();
            
        }
        if (respuesta == 2){
            
            String carpetaAct = System.getProperty("user.dir");
        
            File carpeta = new File (carpetaAct);

            String [] listado = carpeta.list();
            
            verColumna(listado);
            
        }
        if (respuesta == 3){
            
            File f = new File("E:\\2DAM\\AD\\Ficheros\\Ficheros Java");
            
            verTabla(f);
            
        }
    }
    
    public static void verLista(){
        
        String carpetaAct = System.getProperty("user.dir");
        
        File carpeta = new File (carpetaAct);
        
        String [] listado = carpeta.list();
        
        if (listado == null || listado.length == 0) {
            
            System.out.println("No hay elementos dentro del directorio");
            
            return;
        }
        else {
            
            for (int i = 0; i < listado.length; i++){
                
                System.out.println(listado[i]);
                
            }
            
        }
        
    }
    
    public static void verColumna(String [] filenames){
        
        int MAX_FILES_BY_COLUMN = 4;
        
        int columnas = (filenames.length / MAX_FILES_BY_COLUMN)+1;
        String[][] salida = new String[MAX_FILES_BY_COLUMN][columnas];
        for (int i=0;i<filenames.length;i++){
            salida[i % MAX_FILES_BY_COLUMN][i / MAX_FILES_BY_COLUMN]=filenames
            [i];
        }
            //bucle para mostrar salidals
        for (int i=0;i<MAX_FILES_BY_COLUMN;i++){
            for (int j=0; j<columnas;j++)
            System.out.print(salida[i][j] + " - ");
            System.out.println(" /");
        }
        
    }
    
    public static void verTabla(File f){
        
        String imprimir = "";
        
        for (File archivo : f.listFiles()){
        
            if (archivo.isDirectory()){
                
                imprimir = imprimir + "D";
                
            }
            else {
                
                imprimir = imprimir + "-";
                
            }
            if (archivo.isFile()){
                
                imprimir = imprimir + "F";
                
            }
            else {
                
                imprimir = imprimir + "-";
                
            }
            if (archivo.canRead()){
                
                imprimir = imprimir + "R";
                
            }
            else {
                
                imprimir = imprimir + "-";
                
            }
            if (archivo.canWrite()){
                
                imprimir = imprimir + "W";
                
            }
            else {
                
                imprimir = imprimir + "-";
                
            }
            if (archivo.isHidden()){
                
                imprimir = imprimir + "H";
                
            }
            else {
                
                imprimir = imprimir + "-";
                
            }
            
            imprimir = imprimir + " / " + archivo.getName() + " / " +archivo.length() + " / " + archivo.lastModified() + "\n";
            System.out.println(imprimir);
        }
        
    }
    
}
