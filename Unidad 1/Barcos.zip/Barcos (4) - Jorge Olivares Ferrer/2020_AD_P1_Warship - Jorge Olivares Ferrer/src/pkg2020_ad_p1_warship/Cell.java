/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author joange
 */
public class Cell {

    /**
     * @return the CELL_WATER
     */
    public static int getCELL_WATER() {
        return CELL_WATER;
    }

    /**
     * @return the CELL_BOAT
     */
    public static int getCELL_BOAT() {
        return CELL_BOAT;
    }

    /**
     * @return the CELL_TOUCH
     */
    public static int getCELL_TOUCH() {
        return CELL_TOUCH;
    }

    /**
     * @return the CELL_SUNKEN
     */
    public static int getCELL_SUNKEN() {
        return CELL_SUNKEN;
    }

    /**
     * @return the CELL_FIRED
     */
    public static int getCELL_FIRED() {
        return CELL_FIRED;
    }

    /**
     * @return the CELL_NOT_INITIALIZED
     */
    public static int getCELL_NOT_INITIALIZED() {
        return CELL_NOT_INITIALIZED;
    }

    /**
     * @return the CELL_WATER_CHAR
     */
    public static String getCELL_WATER_CHAR() {
        return CELL_WATER_CHAR;
    }

    /**
     * @return the CELL_BOAT_CHAR
     */
    public static String getCELL_BOAT_CHAR() {
        return CELL_BOAT_CHAR;
    }

    /**
     * @return the CELL_TOUCH_CHAR
     */
    public static String getCELL_TOUCH_CHAR() {
        return CELL_TOUCH_CHAR;
    }

    /**
     * @return the CELL_SUNKEN_CHAR
     */
    public static String getCELL_SUNKEN_CHAR() {
        return CELL_SUNKEN_CHAR;
    }

    /**
     * @return the CELL_SUNKEN_FIRED
     */
    public static String getCELL_SUNKEN_FIRED() {
        return CELL_SUNKEN_FIRED;
    }

    /**
     * @return the fila
     */
    public int getFila() {
        return fila;
    }

    /**
     * @param fila the fila to set
     */
    public void setFila(int fila) {
        this.fila = fila;
    }

    /**
     * @return the columna
     */
    public int getColumna() {
        return columna;
    }

    /**
     * @param columna the columna to set
     */
    public void setColumna(int columna) {
        this.columna = columna;
    }

    /**
     * @param contains the contains to set
     */
    public void setContains(int contains) {
        this.contains = contains;
    }
    // Contantes para controlar el contenido de la celda
    public static final int CELL_WATER = 0;
    public static final int CELL_BOAT = 1;
    public static final int CELL_TOUCH = 2;
    public static final int CELL_SUNKEN = 3;
    public static final int CELL_FIRED = 4;
    public static final int CELL_NOT_INITIALIZED = -1;
    
    // Constantes para controlar lo que ser verá por pantalla
    
    public static final String CELL_WATER_CHAR = "_";
    public static final String CELL_BOAT_CHAR = "X";
    public static final String CELL_TOUCH_CHAR = "T";
    public static final String CELL_SUNKEN_CHAR = "H";
    public static final String CELL_SUNKEN_FIRED = "o";
    
    // Inicializació de variabl privadas
    private int fila = 0;     // fila en la que se encuentra la celda
    private int columna = 0;  // Columna en la que se eunentra la celda
    private int contains  = CELL_NOT_INITIALIZED; //Contenido de la celda
    private Boat boat; // Si la celda contiene parte de un bote ..
    
    public Cell(int fila, int columna){ 
        // Al crear la celda inicializamos los valores....    
        this.fila = fila;
        this.columna = columna;
        this.contains = CELL_WATER;
        boat = null;
    }
    
    public void setBoat(Boat boat){
        // Si ponemos un bote en la celda cambiamos los valores de las propiedades
        this.boat = boat; // Puntero al objeto bote que contien la celda
        this.setContains(getCELL_BOAT());
    }
    
    // Se utilizará cuando caiga una bomba sobre la celda y esta contnega un bote
    public void setTouch() {
        this.setContains(getCELL_TOUCH());
    }
    
    // se utilizará cuando todas las celdas ocupadas por un barco estén tocadas
    public void setSunken() {
        this.setContains(getCELL_SUNKEN());
    }
    
        // se utilizará cuando todas las celdas ocupadas por un barco estén tocadas
    public void setFired() {
        this.setContains(getCELL_FIRED());
    }
    
    // Métodos para establecer/consultas las propiedades
    public Boat getBoat(){return boat;}
    public int getRow(){return this.getFila();}
    public int getColumn(){return this.getColumna();}
    public int getContains(){return this.contains;}
    
    //Método para controlar el texto que aparecerá en pantalla
    public String getContainsString() {
        if (this.getContains() == getCELL_WATER()) return getCELL_WATER_CHAR();
        if (this.getContains() == getCELL_BOAT()) return getCELL_BOAT_CHAR();
        if (this.getContains() == getCELL_TOUCH()) return getCELL_TOUCH_CHAR();
        if (this.getContains() == getCELL_SUNKEN()) return getCELL_SUNKEN_CHAR();
        if (this.getContains()== getCELL_FIRED()) return getCELL_SUNKEN_FIRED();
        return "E"; // Si devuelve E 'Error' no está inicializado
    }
    
    //Sobreescribe el método tostring de Object.
    @Override
    public String toString(){
        return "(" + this.getFila() + ", " + this.getColumna() + ")  --> " + this.getContainsString();
    }
    
}
