
import Utils.ConsoleColors;
import Utils.Leer;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author joange
 */
public class WarShip {

    /**
     * @return the MAX_JUGADAS
     */
    public static int getMAX_JUGADAS() {
        return MAX_JUGADAS;
    }

    /**
     * @return the r
     */
    public Random getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(Random r) {
        this.r = r;
    }

    /**
     * @return the board
     */
    public Board getBoard() {
        return board;
    }

    /**
     * @param board the board to set
     */
    public void setBoard(Board board) {
        this.board = board;
    }

    /**
     * @return the ws
     */
    public WarShip getWs() {
        return ws;
    }

    /**
     * @param ws the ws to set
     */
    public void setWs(WarShip ws) {
        this.ws = ws;
    }

    /**
     * @param args the command line arguments
     */
    private static final int MAX_JUGADAS = 100;

    private Random r;
    private Board board;
    private WarShip ws;

    public WarShip() {
        r = new Random(System.currentTimeMillis());
        board = new Board();
        board.initBoats();
    }
    
    private void autoPlay() {

        getBoard().paint();
        File fichero = new File("moviments_in.txt");
        
        try {
            
            FileReader fr = new FileReader (fichero);
            BufferedReader br = new BufferedReader(fr);
            
            while (br.ready()){
                
                String linea = br.readLine();
                String [] palabra = linea.split(";");
                
                System.out.println(ConsoleColors.GREEN_BRIGHT+"JUGADA: " + palabra[0]);
                
                int fila, columna;
                
                do {
                    
                    fila = Integer.parseInt(palabra[1]);
                    columna = Integer.parseInt(palabra[2]);
                    
                }while (getBoard().fired(fila, columna));
                
                int resultado = getBoard().shot(fila, columna);
                if (resultado != Cell.CELL_WATER){
                    
                    getBoard().paint();
                    
                } else {
                    
                    System.out.println("(" + fila + "," + columna + ") --> AGUA");
                    
                }
                
                if (getBoard().getEnd_Game()){
                    
                    System.out.printf("Joc acabat amb %2d jugades\n", palabra[0]);
                    break;
                }
                
            }
                
            } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    
    public static void renombrarFicheros(){
        
        File f1 = new File ("boat_out.txt");
        File f2 = new File ("boat_in.txt");
        
        boolean correcto = f1.renameTo(f2);
        
        if (correcto){
            
            System.out.println("El renombrado del fichero boat ha sido correcto!");
            
        }
        else{
            
            System.out.println("El renombrado del fichero boat no se ha podido realizar!");
            
        }
        
        File f3 = new File ("moviments_out.txt");
        File f4 = new File ("moviments_in.txt");
        
        boolean correcto1 = f3.renameTo(f4);
        
        if (correcto1){
            
            System.out.println("El renombrado del fichero moviments ha sido correcto!");
            
        }
        else {
            
            System.out.println("El renombrado del fichero moviments no se ha podido realizar!");
            
        }
        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        renombrarFicheros();
        
        Scanner reader = new Scanner (System.in);
        
        WarShip ws = new WarShip();

        Board.guardarConfiguración();
        
        int opcio = 0;
        do {
            System.out.println(ConsoleColors.GREEN+"--    Escollir   --");
            System.out.println(ConsoleColors.GREEN+"1. Joc automàtic...");
            System.out.println(ConsoleColors.GREEN+"2. Joc manual......");
            opcio = Leer.leerEntero(ConsoleColors.CYAN+"Indica el tipus de joc que vols: "+ConsoleColors.RESET);
        } while (opcio < 1 || opcio > 2);

        switch (opcio) {
            case 1:
                ws.autoPlay();
                break;
        }
    }
}
