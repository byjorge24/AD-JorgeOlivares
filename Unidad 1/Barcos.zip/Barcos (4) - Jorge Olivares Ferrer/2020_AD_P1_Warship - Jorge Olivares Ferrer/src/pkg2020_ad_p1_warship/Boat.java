
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joange
 */
public class Boat {

    /**
     * @return the BOAT_OK
     */
    public static int getBOAT_OK() {
        return BOAT_OK;
    }

    /**
     * @return the BOAT_TOUCHED
     */
    public static int getBOAT_TOUCHED() {
        return BOAT_TOUCHED;
    }

    /**
     * @return the BOAT_SUNKEN
     */
    public static int getBOAT_SUNKEN() {
        return BOAT_SUNKEN;
    }

    /**
     * @return the BOAT_DIR_HOR
     */
    public static int getBOAT_DIR_HOR() {
        return BOAT_DIR_HOR;
    }

    /**
     * @return the BOAT_DIR_VER
     */
    public static int getBOAT_DIR_VER() {
        return BOAT_DIR_VER;
    }

    /**
     * @return the dimension
     */
    public int getDimension() {
        return dimension;
    }

    /**
     * @param dimension the dimension to set
     */
    public void setDimension(int dimension) {
        this.dimension = dimension;
    }

    /**
     * @return the cells
     */
    public Cell[] getCells() {
        return cells;
    }

    /**
     * @param cells the cells to set
     */
    public void setCells(Cell[] cells) {
        this.cells = cells;
    }

    /**
     * @return the estado
     */
    public int getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(int estado) {
        this.estado = estado;
    }
    //Constantes para controlar el estado general del barco
    private static final int BOAT_OK = 0;
    private static final int BOAT_TOUCHED = 1;
    private static final int BOAT_SUNKEN = 2;
    
    //Constantes para controlar su orientación
    private static final int BOAT_DIR_HOR = 0;
    private static final int BOAT_DIR_VER = 1;
    
    // Propiedades
    private int dimension=0;
    private Cell[] cells;
    private int estado = BOAT_OK;
    
    // Constructor
    public Boat(){
        //Vacío, las propiedades se establecen en su iniciaización
    }
    
    // Para consultar el estado de un barco
    public int getBoatState(){return getEstado();}
   
    // Establece la dimensión del barco y lo coloca en el tablero si cabe
    
    public void setBoat(String [] array){
       
        //Posicionamiento aleatorio
        int fila = Integer.parseInt(array[3]);
        int columna = Integer.parseInt(array[4]);
        int dir = Integer.parseInt(array[2]);
                
    }
    
    // Controla si el bote cabe el el tablero
    private boolean boatFits(int fila, int columna, int dimension, int direccion, Board board){
        int min_col = 0, max_col=0, min_row=0, max_row=0;
        
        // los barcos se colocan de fila, columna hacia la derecha o hacia abajo
        // Dependiendo de la orientación calcula el recuadro a controlar
        
        if (direccion == this.getBOAT_DIR_HOR()) {
            if ((columna + dimension) > Board.getBOARD_DIM()) return false; // El barco no cabe
            
            min_col = board.fitValueToBoard(columna - 1);
            max_col = board.fitValueToBoard(columna + dimension);
            
            min_row = board.fitValueToBoard(fila - 1);
            max_row = board.fitValueToBoard(fila + 1);
        }
        if (direccion == this.getBOAT_DIR_VER()) {
            if ((fila + dimension) > Board.getBOARD_DIM()) return false; // El barco no cabe
            
            min_col = board.fitValueToBoard(columna - 1);
            max_col = board.fitValueToBoard(columna + 1);
            
            min_row = board.fitValueToBoard(fila - 1);
            max_row = board.fitValueToBoard(fila + dimension);
        }
        
        // Recorre la matriz que contendrá el barco para asegurarse que no hay ninguno
        for (int i=min_row; i<=max_row; i++){
            for (int j=min_col; j<=max_col; j++) {
                if (board.getCell(i, j).getContains()==Cell.getCELL_BOAT()) return false; // Ya hay un barco
            }
        }
        return true;
    }
    
    // Cuando una shot cae sobre un barco
    public int touchBoat(int fila, int columna){
        int tocados = 0;
        //Si ya está hundido no puede empeorar
        if (getEstado() == getBOAT_SUNKEN()) return getBOAT_SUNKEN(); 
        
        // Si no está hundido como mínimo estará tocado
        setEstado(Boat.getBOAT_TOUCHED());
        
        // Comprueba si esta parte del barco aún no habia sido tocada
        // Cuenta los tocados para saber si está hundido
        for (int i = 0; i < getDimension(); i++) {
            Cell c = getCells()[i];
            if ((c.getRow() == fila) && (c.getColumn() == columna)) {
                if (c.getContains() == Cell.getCELL_BOAT()) c.setTouch();
            }
            if (c.getContains() == Cell.getCELL_TOUCH())  tocados++;
        }
        // Si todas las partes del barco están tocadas ... Cambiar estado a hundido
        if (tocados == getDimension()) {
            // Hundido ....
            for (int i=0; i<getDimension(); i++) {
                Cell c = getCells()[i];
                c.setSunken();
            }
            setEstado(getBOAT_SUNKEN());
        }
        
        return getEstado();
    }
    
    // Para mostrar por pantalla las celdas que ocupa un barco
    public void viewCells(){
        System.out.print("Posiciones: {");
        for (int i = 0; i < getDimension(); i++) {
            Cell c = getCells()[i];
            System.out.print("(" + c.getRow() + ", " + c.getColumn() + ")");
        }
        System.out.println(" }");
    }
}
